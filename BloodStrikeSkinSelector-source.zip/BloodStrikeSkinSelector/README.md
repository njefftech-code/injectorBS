# Strike Skin Lab — Android prototype

A native Android Studio project for a local gun-skin selector / cosmetic preview mockup.

## Build
1. Open this folder in Android Studio (current stable version).
2. Allow Gradle sync and install the Android SDK platform requested by the project (API 35).
3. Choose **Build > Build APK(s)**.
4. Install the debug APK on your own Android test device.

## Included
- Weapon-category filters (All, Rifle, SMG, Sniper, Shotgun)
- Six fictional cosmetic entries
- Selected-skin preview panel
- Local-only selection feedback
- No network permission and no game-process access

## Scope
This is a functional UI prototype, not an injector. It does not alter Blood Strike files, memory, assets, matchmaking, or server state, and it cannot unlock paid or unavailable skins. The skin names and weapon illustration are fictional placeholders.
