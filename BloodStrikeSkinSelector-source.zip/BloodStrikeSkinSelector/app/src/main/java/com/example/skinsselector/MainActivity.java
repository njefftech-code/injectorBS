package com.example.skinsselector;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private final String[] weapons = {"All", "Rifle", "SMG", "Sniper", "Shotgun"};
    private final String[][] skins = {
        {"PHANTOM CORE", "RIFLE", "◆ LEGENDARY", "#FF5B35"},
        {"NEON CIRCUIT", "SMG", "◆ EPIC", "#28D7D0"},
        {"FROSTBITE", "SNIPER", "◆ EPIC", "#82B7FF"},
        {"GOLDEN STRIKE", "RIFLE", "◆ RARE", "#E6BC52"},
        {"VOID RUNNER", "SHOTGUN", "◆ RARE", "#B68AFF"},
        {"EMBER SHIFT", "SMG", "◆ UNCOMMON", "#FF8A45"}
    };
    private String selectedWeapon = "All";
    private String selectedSkin = "PHANTOM CORE";
    private LinearLayout list;
    private TextView previewName, previewType, previewRarity;
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private int color(String s) { return Color.parseColor(s); }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(color("#101216"));
        getWindow().setNavigationBarColor(color("#101216"));
        buildUi();
    }

    private GradientDrawable bg(String c, int radius, String stroke) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color(c)); d.setCornerRadius(dp(radius));
        if (stroke != null) d.setStroke(dp(1), color(stroke)); return d;
    }
    private TextView text(String value, int size, String c, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color(c));
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return t;
    }
    private LinearLayout column() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private LinearLayout row() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    private void buildUi() {
        LinearLayout root = column(); root.setBackgroundColor(color("#101216"));
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true);
        LinearLayout page = column(); page.setPadding(dp(18), dp(16), dp(18), dp(28));
        LinearLayout brand = row();
        TextView mark = text("S", 23, "#FFFFFF", true); mark.setGravity(Gravity.CENTER); mark.setBackground(bg("#FF5B35", 12, null));
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(dp(44), dp(44)); mp.rightMargin = dp(12); brand.addView(mark, mp);
        LinearLayout titles = column(); titles.addView(text("STRIKE SKIN LAB", 17, "#FFFFFF", true)); titles.addView(text("WEAPON COSMETIC PREVIEW", 10, "#9298A5", true)); brand.addView(titles, new LinearLayout.LayoutParams(0, -2, 1));
        brand.addView(text("DEMO 01", 10, "#FF805F", true)); page.addView(brand);
        TextView heading = text("Loadout studio", 28, "#FFFFFF", true); LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2); hp.topMargin = dp(25); page.addView(heading, hp);
        TextView sub = text("Choose a weapon skin and preview its style.", 13, "#9BA1AD", false); LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2); sp.topMargin = dp(5); page.addView(sub, sp);

        LinearLayout preview = column(); preview.setPadding(dp(16), dp(16), dp(16), dp(16)); preview.setBackground(bg("#1A1D24", 18, "#303541"));
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, -2); pp.topMargin = dp(20); page.addView(preview, pp);
        LinearLayout top = row(); top.addView(text("LIVE PREVIEW", 10, "#A7ADBA", true), new LinearLayout.LayoutParams(0, -2, 1)); top.addView(text("● LOCAL ONLY", 10, "#62D7A4", true)); preview.addView(top);
        TextView weaponArt = text("╱━━━━━━━━━━━━━━━━━━╲\n   ▰━━━━━━━▰━━━▷\n╲━━━━━━━━━━━━━━━━━━╱", 18, "#FF805F", true); weaponArt.setGravity(Gravity.CENTER); weaponArt.setPadding(0, dp(20), 0, dp(16)); preview.addView(weaponArt);
        previewName = text(selectedSkin, 20, "#FFFFFF", true); preview.addView(previewName);
        LinearLayout info = row(); previewType = text("RIFLE", 11, "#B9BFCA", true); previewRarity = text("◆ LEGENDARY", 11, "#FF805F", true);
        info.addView(previewType); TextView gap = text("   •   ", 11, "#737987", false); info.addView(gap); info.addView(previewRarity); LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1, -2); ip.topMargin = dp(6); preview.addView(info, ip);
        Button apply = new Button(this); apply.setText("SELECT FOR PREVIEW"); apply.setTextColor(Color.WHITE); apply.setAllCaps(false); apply.setTextSize(14); apply.setTypeface(Typeface.DEFAULT, Typeface.BOLD); apply.setBackground(bg("#FF5B35", 12, null));
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, dp(48)); ap.topMargin = dp(16); preview.addView(apply, ap);
        apply.setOnClickListener(v -> Toast.makeText(this, selectedSkin + " selected for local preview. No game files changed.", Toast.LENGTH_LONG).show());

        TextView section = text("WEAPON CATEGORY", 11, "#A7ADBA", true); LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2); cp.topMargin = dp(25); page.addView(section, cp);
        HorizontalScrollView hsv = new HorizontalScrollView(this); hsv.setHorizontalScrollBarEnabled(false); LinearLayout chips = row();
        for (String w : weapons) { TextView chip = text(w, 12, w.equals(selectedWeapon) ? "#FFFFFF" : "#A7ADBA", true); chip.setGravity(Gravity.CENTER); chip.setPadding(dp(16), dp(10), dp(16), dp(10)); chip.setBackground(bg(w.equals(selectedWeapon) ? "#34303A" : "#1A1D24", 20, w.equals(selectedWeapon) ? "#FF5B35" : "#303541")); LinearLayout.LayoutParams cpl = new LinearLayout.LayoutParams(-2, -2); cpl.rightMargin = dp(8); chips.addView(chip, cpl); chip.setOnClickListener(v -> { selectedWeapon = w; buildUi(); }); }
        hsv.addView(chips); LinearLayout.LayoutParams hsp = new LinearLayout.LayoutParams(-1, -2); hsp.topMargin = dp(12); page.addView(hsv, hsp);
        TextView skinsTitle = text("SKIN COLLECTION", 11, "#A7ADBA", true); LinearLayout.LayoutParams stp = new LinearLayout.LayoutParams(-1, -2); stp.topMargin = dp(22); page.addView(skinsTitle, stp);
        list = column(); LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.topMargin = dp(10); page.addView(list, lp); populateSkins();
        TextView note = text("Prototype only • No connection to Blood Strike • Does not unlock or inject skins into the game.", 11, "#777F8D", false); note.setGravity(Gravity.CENTER); note.setPadding(dp(8), dp(22), dp(8), 0); page.addView(note);
        scroll.addView(page); root.addView(scroll); setContentView(root);
    }
    private void populateSkins() {
        list.removeAllViews();
        for (String[] skin : skins) {
            if (!selectedWeapon.equals("All") && !skin[1].equals(selectedWeapon.toUpperCase())) continue;
            boolean selected = selectedSkin.equals(skin[0]);
            LinearLayout card = row(); card.setPadding(dp(13), dp(12), dp(13), dp(12)); card.setBackground(bg(selected ? "#25232B" : "#191C22", 14, selected ? skin[3] : "#2C3039"));
            LinearLayout.LayoutParams cardp = new LinearLayout.LayoutParams(-1, -2); cardp.bottomMargin = dp(9); list.addView(card, cardp);
            TextView swatch = text("◆", 25, skin[3], true); swatch.setGravity(Gravity.CENTER); swatch.setBackground(bg("#272B34", 12, null)); LinearLayout.LayoutParams swp = new LinearLayout.LayoutParams(dp(54), dp(54)); swp.rightMargin = dp(12); card.addView(swatch, swp);
            LinearLayout meta = column(); meta.addView(text(skin[0], 13, "#FFFFFF", true)); TextView details = text(skin[1] + "  •  " + skin[2], 10, skin[3], true); LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(-1, -2); dp.topMargin = dp(5); meta.addView(details, dp); card.addView(meta, new LinearLayout.LayoutParams(0, -2, 1));
            TextView action = text(selected ? "SELECTED" : "PREVIEW  ›", 10, selected ? skin[3] : "#B7BDCA", true); card.addView(action);
            card.setOnClickListener(v -> { selectedSkin = skin[0]; buildUi(); });
        }
    }
}
